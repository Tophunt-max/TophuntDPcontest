// apps/functions/src/index.ts
import { setGlobalOptions } from "firebase-functions/v2";

// 1. GLOBAL DEFAULTS (No Global Concurrency!)
setGlobalOptions({ 
    region: "us-central1", // Cheaper, Standard
    maxInstances: 2,       // Hard Limit for Cost Control
    minInstances: 0,       // Scale to Zero (Free when idle)
    memory: "256MiB",      // Lowest Memory Tier
    timeoutSeconds: 60,    // Short timeout to free resources
});

// 2. EXPORTED FUNCTIONS
// Grouped logically to reduce cold starts if needed, but keeping separate for now
// to maintain clear separation of concerns as requested.

// Auth & User Management (Merged into authHandler)
export * from "./auth/authHandler";
export * from "./user/emailUpdate";
export * from "./user/phoneUpdate";
export * from "./user/toggleFollow";

// Content & Features
export * from "./stories/index";
export * from "./posts/index";
export * from "./notifications/index";
export * from "./storage/presignedUrl";

// Contest & Gamification (Critical Path)
// MERGED: joinContest and voteInBattle are now contestHandler
export * from "./contests/contestHandler"; 
export * from "./contests/finalize";

// Wallet
export * from "./wallet/topup";

// Admin Functions
export * from "./admin/index";
export * from "./admin/notifications";
