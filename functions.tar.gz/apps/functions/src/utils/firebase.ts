import * as admin from "firebase-admin";
import { getFirestore } from "firebase-admin/firestore";

if (admin.apps.length === 0) {
  admin.initializeApp();
}

// Connect to the default database instance
// Previously connected to "dpcontest"
export const db = getFirestore();

// Keep dpDb export for backward compatibility during migration but point to default db
export const dpDb = db;

export const auth = admin.auth();
export { admin };
